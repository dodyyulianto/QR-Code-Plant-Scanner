package id.ac.unja.si.siitscanner.common;

import com.journeyapps.barcodescanner.CaptureActivity;

public class ZXingOrientation extends CaptureActivity {

}
